<?php

namespace OM4\Zapier\Payload;

use OM4\Zapier\Payload\Base\Item;

defined( 'ABSPATH' ) || exit;

/**
 * Null Object for Payloads.
 *
 * @deprecated 2.0.0
 */
class NullPayload extends Item {}
