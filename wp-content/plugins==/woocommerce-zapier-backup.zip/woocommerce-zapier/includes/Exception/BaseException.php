<?php

namespace OM4\Zapier\Exception;

use Exception;

defined( 'ABSPATH' ) || exit;

/**
 * All Exception in OM4\Zapier namespace must extend this.
 */
abstract class BaseException extends Exception {}
