<?php

namespace OM4\Zapier\Payload;

use OM4\Zapier\Payload\Base\Item;

defined( 'ABSPATH' ) || exit;

/**
 * Null Object for Payloads.
 */
class NullPayload extends Item {}
