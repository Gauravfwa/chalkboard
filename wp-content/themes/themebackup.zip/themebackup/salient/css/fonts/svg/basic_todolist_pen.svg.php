<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="24" x2="38" y2="24"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="34" x2="38" y2="34"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="44" x2="38" y2="44"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="54" x2="38" y2="54"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="24" x2="8" y2="24"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="34" x2="8" y2="34"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="44" x2="8" y2="44"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="12" y1="54" x2="8" y2="54"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="14,8 1,8 1,63 45,63 45,8 32,8 "/>
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="27,5 27,1 19,1 19,5 15,5 13,13 33,13 31,5 
	"/>
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="63,3 63,53 59,61 55,53 55,3 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="55,7 51,7 51,17 "/>
</svg>
