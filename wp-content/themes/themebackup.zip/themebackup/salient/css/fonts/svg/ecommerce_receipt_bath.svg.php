<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.0"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="52,62.999 52,0.999 26,0.999 12,14.999 
		12,63 16,61 20,63 24,61 28,63 32,61 36,63 40,61 44,63 48,61 	"/>
	<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="12,14.999 26,14.999 26,0.999 	"/>
</g>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="26" y1="48" x2="26" y2="22"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M26,23h5c0,0,6,0,6,6c0,5-6,5-6,5h-5"/>
<path fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" d="M27,34h5c0,0,7-0.226,7,7c0,6-7,6-7,6h-6"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="20" x2="32" y2="50"/>
</svg>
