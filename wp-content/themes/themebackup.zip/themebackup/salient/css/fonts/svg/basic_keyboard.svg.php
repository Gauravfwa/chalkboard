<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="22" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="30"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="7,22 7,14 21,14 21,7 11,7 11,4 "/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="4" y1="29" x2="8" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="10" y1="29" x2="14" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="29" x2="20" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="22" y1="29" x2="26" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="28" y1="29" x2="32" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="34" y1="29" x2="38" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="40" y1="29" x2="44" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="46" y1="29" x2="50" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="52" y1="29" x2="56" y2="29"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="4" y1="45" x2="8" y2="45"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="10" y1="45" x2="14" y2="45"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="16" y1="45" x2="42" y2="45"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="50" y1="45" x2="54" y2="45"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="56" y1="45" x2="60" y2="45"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="44" y1="45" x2="48" y2="45"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="8" y1="37" x2="12" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="14" y1="37" x2="18" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="20" y1="37" x2="24" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="26" y1="37" x2="30" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="37" x2="36" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="38" y1="37" x2="42" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="44" y1="37" x2="48" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="50" y1="37" x2="54" y2="37"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="56" y1="37" x2="60" y2="37"/>
</svg>
