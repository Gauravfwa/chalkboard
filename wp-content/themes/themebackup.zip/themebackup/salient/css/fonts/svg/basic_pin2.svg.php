<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="32" y1="64" x2="32" y2="36"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="32,1 22,1 22,5 27,9 25,26 16,30 15,36 
	32,36 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="32,1 42,1 42,5 37,9 39,26 48,30 49,36 
	32,36 "/>
</svg>
