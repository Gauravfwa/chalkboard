<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<rect x="1" y="18" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="52" height="32"/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="9.887,16 9.887,9 63,9 63,41 55,41 "/>
<polyline fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="0.887,18 27,33.062 53,18 "/>
</svg>
